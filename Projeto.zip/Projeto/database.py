from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase

engine = create_engine("sqlite:///biblioteca.db")


class Base(DeclarativeBase):
    pass

Session = sessionmaker(bind=engine)
