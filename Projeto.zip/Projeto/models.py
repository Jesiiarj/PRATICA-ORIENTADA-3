from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import String, ForeignKey
from database import Base


class User(Base):
    __tablename__ = "users"


class Book(Base):
    __tablename__ = "books"

