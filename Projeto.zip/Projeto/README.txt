BIBLIOTECA COM FLASK

Arquivos:
- app.py: rotas Flask
- database.py: configuração do SQLite e da sessão
- models.py: modelos User e Book (campos e relacionamento a implementar)
- templates/: páginas HTML
- requirements.txt: dependências

Para instalar as dependências:
    pip install -r requirements.txt

Para iniciar, depois de completar os TODOs:
    python app.py

O relacionamento esperado é 1:N:
- um User pode possuir vários Book
- cada Book pertence a um User

